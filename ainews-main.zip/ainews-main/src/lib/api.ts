import { SummaryResult } from '../types';
import axios from 'axios';

export async function summarizeArticles(
  articles: { title: string; content: string }[],
  targetLanguages: string[]
): Promise<SummaryResult> {
  try {
    const response = await axios.post('/api/summarize', {
      articles,
      targetLanguages
    });
    return response.data;
  } catch (error: any) {
    console.error("Summarize error via proxy:", error);
    throw new Error(error.response?.data?.error || "Failed to generate summary");
  }
}

export async function translateText(
  text: string, 
  targetLanguage: string, 
  originalHeadline: string
): Promise<{ headline: string; summary: string; highlights: string[] }> {
  try {
    const response = await axios.post('/api/translate', {
      text,
      targetLanguage,
      originalHeadline
    });
    return response.data;
  } catch (error: any) {
    console.error("Translation error via proxy:", error);
    throw new Error(error.response?.data?.error || "Failed to translate text");
  }
}
