import { createClient } from '@supabase/supabase-js';

// Safe to fallback since VITE_ variables are injected to client-side explicitly 
let supabaseUrl = import.meta.env.VITE_SUPABASE_URL || 'https://qdcjmexxzoovlsrxwfav.supabase.co';
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY || 'sb_publishable_OTvAl5wczBqWI90rxTqaiA_t7CBwfzZ';

// Clean up accidental malformed characters in the environment variable like < > or trailing dots
supabaseUrl = supabaseUrl.replace(/[<>]/g, '').replace(/\.$/, '');

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

